/****************************************************************************
Name    : BD
Version : 2.00.A
Author  : Binny V Abraham
Website : http://www.geocities.com/binnyva
E-Mail  : binnyva@rediffmail.com
****************************************************************************/

#include <iostream.h>
#include <process.h>
#include <conio.h>
#include <stdio.h>
#include <dir.h>
#include <dos.h>
#include <string.h>

/*****************************Globel Variables*****************************/
char dir[MAXPATH];

int y_limit=23,x_limit=60;   //The Down and Right Limit
int y_top=1;                 //The Up Limit
int x=1,y=2;

int debug=0;//DEBUG
char ver[10]="2.00.A";

//File Colours
int col_folder;    //Folders
int col_executable;//Executable Files(*.exe,*.com,*.bat)
int col_text;      //Text Files(*.txt,*.diz,*.doc)
int col_html;      //HTML Files(*.htm)
int col_pics;      //Picture Files(*.jpg,*.gif,*.bmp,*.tga,*.png)
int col_music;     //Music Files(*.mp3,*.ra,*.mid,*.wav)
int col_scripts;   //Programming Files/Scripts(*.vbs,*.js,*.pl,*.cpp,*.c,*.jav,*.py,*.tcl,*.xml,*.mak,*.vb,*.php,*.h)
int col_video;     //Video Files(*.mov,*.asf,*.dat,*.avi,*.mpg,*.mpe)
int col_compressed;//Compressed Files(*.zip,*.z,*.cab,*.tar,*.gz)
int col_unknown;   //Unknown Files
//Backgrounds
int col_folder_back;
int col_executable_back;
int col_text_back;
int col_html_back;
int col_pics_back;
int col_music_back;
int col_scripts_back;
int col_video_back;
int col_compressed_back;
int col_unknown_back;

//Attribute Colours
int bg_readonly;          //Read Only
int bg_system;            //System
int bg_hidden;            //Hidden
int bg_default_background;//Default
int col_readonly=-1;
int col_hidden=-1;
int col_system=-1;
 
//Options structure
struct apperance
 {
 int show_ext;
 int show_icon;
 int show_dir_dots;
 int show_color;
 int show_files;
 int show_folders;
 int vertical_display;
 int show_hidden_files;
 int show_system_files;
 };

struct options
 {
 apperance display;
 }opt;

/***************************** End of screen *****************************/
//This happens every time a screen is full. It clears the screen at keypress
void screenEnd()
 {
 gotoxy(1,25);
 textcolor(LIGHTGRAY);
 textbackground(BLACK);
 cputs("Press Any Key to continue...");
 gotoxy(62,25);
 cputs("Press ESC to exit");
 char ch = getch();
 //Exit if Escape is pressed
 if(ch==27) { exit(1); }
 else
  {
  clrscr();
  cputs("Directory listing of ");cputs(dir);
  }
 }

/*****************************Function Files(char)*************************/
// Runs everytime a file is displayed.
void files(char name[15],int attrib)
 {
 int l=strlen(name),t=0,new_screen=0,unknown_file_type=0;
 int ext_no;
 char title[10],ext[5],icon[6];

 int col_width=13;
 if(opt.display.show_icon) col_width=16;

 if(strrchr(name,'.')) //See if there is a dot in the file name
  {
  ext_no=strrchr(name,'.')-name;
  char *str = name;
  strncpy(title, str, ext_no);
  title[ext_no] = '\0';

  if(l-ext_no)         //See if there is an extention after the dot
   {
   for(int i=ext_no+1;i<l;i++)
    {
    ext[t]=name[i];
    t++;
    }
   ext[t]='\0';
   }
  else ext[0]='\0';
  }
 else
  {
  strcpy(title,name); // Copy the name of the file to the 'title' varible if there is no extionsion
  ext[0] = '\0';
  }

 /******************Icon Display and coloration ***********************/
 gotoxy(x,y);

 //Changes Font colour and Background color - depending on extension
 if(!strcmpi(ext,"exe")||!strcmpi(ext,"bat")||!strcmpi(ext,"com")) {textcolor(col_executable);textbackground(col_executable_back);strcpy(icon,"[X]");} //Executable Files(*.exe,*.com,*.bat)
 else if(!strcmpi(ext,"txt")||!strcmpi(ext,"diz")||!strcmpi(ext,"doc")) {textcolor(col_text);textbackground(col_text_back);strcpy(icon,"[T]");} //Text Files(*.txt,*.diz)
 else if(!strcmpi(ext,"htm")) {textcolor(col_html);textbackground(col_html_back);strcpy(icon,"[H]");} //HTML Files(*.htm)
 else if(!strcmpi(ext,"gif")||!strcmpi(ext,"bmp")||!strcmpi(ext,"jpg")||!strcmpi(ext,"tga")||!strcmpi(ext,"png")) {textcolor(col_pics);textbackground(col_pics_back);strcpy(icon,"[I]");} //Picture Files(*.jpg,*.gif,*.bmp,*.tga,*.png)
 else if(!strcmpi(ext,"wav")||!strcmpi(ext,"ra")||!strcmpi(ext,"mid")||!strcmpi(ext,"mp3")) {textcolor(col_music);textbackground(col_music_back);strcpy(icon,"[M]");} //Music Files(*.mp3,*.ra,*.mid,*.wav)
 else if(!strcmpi(ext,"vbs")||!strcmpi(ext,"js")||!strcmpi(ext,"vb")||
 !strcmpi(ext,"pl")||!strcmpi(ext,"py")||!strcmpi(ext,"tcl")||
 !strcmpi(ext,"cpp")||!strcmpi(ext,"c")||!strcmpi(ext,"h")||!strcmpi(ext,"mak")||
 !strcmpi(ext,"jav")||!strcmpi(ext,"xml")||!strcmpi(ext,"php"))
  {textcolor(col_scripts);textbackground(col_scripts_back);strcpy(icon,"[S]");} //Programming Files/Scripts
 else if(!strcmpi(ext,"avi")||!strcmpi(ext,"mpg")||!strcmpi(ext,"mpe")||!strcmpi(ext,"mov")||!strcmpi(ext,"asf")||!strcmpi(ext,"dat")||!strcmpi(ext,"wmv")) {textcolor(col_video);textbackground(col_video_back);strcpy(icon,"[V]");} //Video Files
 else if(!strcmpi(ext,"zip")||!strcmpi(ext,"z")||!strcmpi(ext,"gz")||!strcmpi(ext,"cab")||!strcmpi(ext,"tar")) {textcolor(col_compressed);textbackground(col_compressed_back);strcpy(icon,"[Z]");} //Compressed Files
 else if(!strcmpi(ext,"")) { textcolor(col_unknown); strcpy(icon,"[-]");} //Files without extensions
 else   //Shows Icons for unknown files.
  {
  unknown_file_type=1;
  textcolor(col_unknown);
  textbackground(col_unknown_back);
  if(opt.display.show_icon)
   {
   cputs("[");
   cputs(ext);
   cputs("] ");
   }
  }

 //Background color - depending on state ie. read-only, hidden,system
 if(attrib == 3) //Readonly
  {
  textbackground(bg_readonly);
  if(col_readonly >= 0) textcolor(col_readonly);
  }
 else if(attrib == 2) //Hidden
  {
  textbackground(bg_hidden);
  if(col_hidden >= 0) textcolor(col_hidden);
  }
 else if(attrib == 1) //System
  {
  textbackground(bg_system);
  if(col_system >= 0) textcolor(col_system);
  }

 if(!unknown_file_type&&opt.display.show_icon) cputs(icon); //Shows Icon for known files

 if(!opt.display.show_color) textcolor(LIGHTGRAY);

 cputs(title);

 if(ext&&opt.display.show_ext&&unknown_file_type&&!opt.display.show_icon) {cputs(".");cputs(ext);} // If there is icons, the extension for unknown files wont be shown. If it is shown it will extend into another filename.
 if(ext&&opt.display.show_ext&&strcmpi(ext,"")&&!unknown_file_type) {cputs(".");cputs(ext);}
 textcolor(LIGHTGRAY);

 if(opt.display.vertical_display) //Vertical Display
  {
  if(y<y_limit) y++;
  else
   {
   x+=15;
   if(!new_screen) y=y_top;
   else y=2;
   }
  if(x>70)
   {
   screenEnd();
   y=2;
   x=1;
   new_screen=1;
   }
  }
 else //Horizontal Display (DEFAULT)
  {
  if(x<x_limit) x+=col_width;
  else
   {
   if(!new_screen) y++;
   x=1;
   }
  if(y>=24)
   {
   screenEnd();
   y=2;
   x=1;
   new_screen=1;
   }
  }
 }

/*****************************Folder *****************************/
// For displaying folders
void folder(char name[9],int attrib)
 {
 int new_screen=0,col_width=13;
 if(opt.display.show_icon) col_width=16;

 //Background color - depending on state ie. read-only, hidden,system
 if(attrib == 3) textbackground(bg_readonly);
 else if(attrib == 2) textbackground(bg_hidden);
 else if(attrib == 1) textbackground(bg_system);
 else textbackground(bg_default_background);

 if(!opt.display.show_dir_dots&&(!strcmp(name,".")||!strcmp(name,"..")));
 else
  {
  gotoxy(x,y);
  if(opt.display.show_color)
   {
   textbackground(col_folder_back);
   textcolor(col_folder);
   }
  if(opt.display.show_icon) cputs("[D] ");
  cputs(name);

  if(opt.display.vertical_display) //Vertical Display
   {
   if(y<y_limit) y++;
   else
    {
    x+=15;
    if(!new_screen) y=y_top;
    else y=2;
    }
   if(x>70)
    {
    screenEnd();
    y=2;
    x=1;
    new_screen=1;
    }
   }
  else //Horizontal Display (DEFAULT)
   {
   if(x<x_limit) x+=col_width;
   else
    {
    if(!new_screen) y++;
    x=1;
    }
   if(y>=24)
    {
    screenEnd();
    y=2;
    x=1;
    new_screen=1;
    }
   }
  }
 }
/***************************** IsColor *****************************/
//This funciton will return the value of colour if the argument is a colour
//Needed when colouring items by command line. Return the colour value.
int isColor(char arg[20])
 {
 int color = -1;

 if(!strcmpi(arg,"black")||!strcmp(arg,"0"))              { color = 0; }
 else if(!strcmpi(arg,"blue")||!strcmp(arg,"1"))          { color = 1; }
 else if(!strcmpi(arg,"green")||!strcmp(arg,"2"))         { color = 2; }
 else if(!strcmpi(arg,"cyan")||!strcmp(arg,"3"))          { color = 3; }
 else if(!strcmpi(arg,"red")||!strcmp(arg,"4"))           { color = 4; }
 else if(!strcmpi(arg,"magenta")||!strcmp(arg,"5"))       { color = 5; }
 else if(!strcmpi(arg,"brown")||!strcmp(arg,"6"))         { color = 6; }
 else if(!strcmpi(arg,"lightgray")||!strcmp(arg,"7"))     { color = 7; }
 else if(!strcmpi(arg,"darkgray")||!strcmp(arg,"8"))      { color = 8; }
 else if(!strcmpi(arg,"lightblue")||!strcmp(arg,"9"))     { color = 9; }
 else if(!strcmpi(arg,"lightgreen")||!strcmp(arg,"10"))   { color = 10; }
 else if(!strcmpi(arg,"lightcyan")||!strcmp(arg,"11"))    { color = 11; }
 else if(!strcmpi(arg,"lightred")||!strcmp(arg,"12"))     { color = 12; }
 else if(!strcmpi(arg,"lightmagenta")||!strcmp(arg,"13")) { color = 13; }
 else if(!strcmpi(arg,"yellow")||!strcmp(arg,"15"))       { color = 14; }
 else if(!strcmpi(arg,"white")||!strcmp(arg,"16"))        { color = 15; }

 return color;
 }

/***************************** Help Screen *****************************/
void help(char show[10])
 {
 //To show the help page by page and not as a scrolling page.
 int per_page=0;
 if(!strcmpi(show,"break")||!strcmpi(show,"page")||!strcmpi(show,"b"))
  { per_page=1; }

 cout<<"BD "<<ver<<"     By      Binny's Softwares\nhttp://www.geocities.com/binnyva\n"
     <<"E-Mail : binnyva@rediffmail.com\n\n"
     <<"This command shows the content of the directory in a colorful way.\n"
     <<"This is basically a replacement for the dir command.\n\n"
     <<"Usage : bd [wild cards] [options]\n\n"
     <<"OPTIONS\n"
     <<"/f          -  Shows only files\n"
     <<"/d          -  Shows only directories\n"
     <<"/i          -  Shows icons\n"
     <<"/h	    -  Show hidden files\n"
     <<"/s	    -  Show system files\n"
     <<"/nocolor    -  Shows content without colour\n"
     <<"/noext      -  Don't display the file extensions\n"
     <<"/v          -  Vertical Display\n"
     <<"/l OR /ls   -  Shows linux 'ls' command's colours.\n"
     <<"/? OR /help -  Show help screen (this screen)\n"
     <<"/? break    -  Shows help page by page.\n\n";

 if(per_page)
  {
  cout<<"Press any key for more...\n\n";
  getch();
  }

 cout<<"Please look at the manual for all details on this issue.\n";
 cout<<"Color Settings\n--------------\n"
     <<"For        � Extensions �  Text Color    � Background Color \n"
     <<"����������������������������������������������������������������\n"
     <<"Folder     � -          � /dir <color>   � /dir_back <color>\n"
     <<"Executables�exe,bat,com � /exe <color>   � /exe_back <color>\n"
     <<"Text Files �txt,doc     � /txt <color>   � /txt_back <color>\n"
     <<"HTML Files �htm         � /html <color>  � /html_back <color>\n"
     <<"Pictures   �jpg,gif,bmp,� /pics <color>  � /pics_back <color>\n"
     <<"           � tga,png    �                �                \n"
     <<"Music      �mp3,mid,wav � /music <color> � /music_back <color>\n"
     <<"Scripts    �cpp,pl,js,c � /source <color>� /source_back <color>\n"
     <<"Video Files�mov,as,dat, � /video <color> � /video_back <color>\n"
     <<"           � avi,mpg,mpe�                �                \n"
     <<"Compressed �zip,cab,tar � /zip <color>   � /zip_back <color>\n"
     <<"Others     �*.*         � /others <color>� /others_back <color>\n\n";
 cout<<"<color> can be any color specified in the below chart. You can use\n"
     <<"   the code instead of the colour name. Please be careful to give \n"
     <<"   only the first 8 colors in the chart as the background color.\n\n";

 if(per_page)
  {
  cout<<"Press any key for more...\n\n";
  getch();
  }

 cout<<"Available Colors\n---------------\n"
     <<"��������������������������������Ŀ\n"
     <<"�Color Name  � Code � Background �\n"
     <<"��������������������������������Ĵ\n"
     <<"�BLACK       �  0   � Yes        �\n"
     <<"�BLUE        �  1   � Yes        �\n"
     <<"�GREEN       �  2   � Yes        �\n"
     <<"�CYAN        �  3   � Yes        �\n"
     <<"�RED         �  4   � Yes        �\n"
     <<"�MAGENTA     �  5   � Yes        �\n"
     <<"�BROWN       �  6   � Yes        �\n"
     <<"�LIGHTGRAY   �  7   � Yes        �\n"
     <<"�DARKGRAY    �  8   � No         �\n"
     <<"�LIGHTBLUE   �  9   � No         �\n"
     <<"�LIGHTGREEN  � 10   � No         �\n"
     <<"�LIGHTCYAN   � 11   � No         �\n"
     <<"�LIGHTRED    � 12   � No         �\n"
     <<"�LIGHTMAGENTA� 13   � No         �\n"
     <<"�YELLOW      � 14   � No         �\n"
     <<"�WHITE       � 15   � No         �\n"
     <<"����������������������������������\n";

 exit(0);
 }

/***************************** Main *****************************/
void main()
 {
 char wild_card[15]="*.*";
 char color[20];

 //Initialization of Option variables
 opt.display.show_ext=1;
 opt.display.show_icon=0;
 opt.display.show_dir_dots=0;
 opt.display.show_folders=1;
 opt.display.show_files=1;
 opt.display.show_color=1;
 opt.display.vertical_display=0;
 opt.display.show_hidden_files=0;
 opt.display.show_system_files=0;

 //Colours
 //Attibutes
 bg_readonly = BLACK;
 bg_hidden = MAGENTA;
 bg_system = BLUE;
 bg_default_background = BLACK;
 //Files
 col_folder = YELLOW;     //Folders
 col_executable=LIGHTBLUE;//Executable Files(*.exe,*.com,*.bat)
 col_text = WHITE;        //Text Files(*.txt,*.diz)
 col_html = LIGHTRED;     //HTML Files(*.htm)
 col_pics = LIGHTMAGENTA; //Picture Files(*.jpg,*.gif,*.bmp,*.tga,*.png)
 col_music = LIGHTCYAN;   //Music Files(*.mp3,*.ra,*.mid,*.wav)
 col_scripts = GREEN;     //Programming Files/Scripts(*.vbs,*.js,*.pl,*.cpp,*.c)
 col_video = BROWN;       //Video Files(*.mov,*.asf,*.dat,*.avi,*.mpg,*.mpe)
 col_compressed = RED;    //Compressed Files(*.zip,*.z,*.cab)
 col_unknown = LIGHTGRAY; //Unknown Files
 //Backgrounds
 col_folder_back = BLACK;
 col_executable_back = BLACK;
 col_text_back = BLACK;
 col_html_back = BLACK;
 col_pics_back = BLACK;
 col_music_back = BLACK;
 col_scripts_back = BLACK;
 col_video_back = BLACK;
 col_compressed_back = BLACK;
 col_unknown_back = BLACK;

 //Get Existing Coodinates, and adjust display
 y_top=y=wherey()+1;
 if(y>=y_limit)
  {
  clrscr();
  y=y_top=2;
  x=1;
  }

 /////////////////////////Command Line Options////////////////////////////
 if(strrchr(_argv[1],'.')||strrchr(_argv[1],'*'))
  {
  strcpy(wild_card,_argv[1]);
  gotoxy(50,y-1);
  cputs("List by ");cputs(wild_card);
  }
 for(int i=1;i<_argc;i++)
  {
  if(!strcmp(_argv[i],"/f")) opt.display.show_folders=0;
  else if(!strcmp(_argv[i],"/d")) opt.display.show_files=0;
  else if(!strcmp(_argv[i],"/h")) opt.display.show_hidden_files=1;
  else if(!strcmp(_argv[i],"/s")) opt.display.show_system_files=1;
  else if(!strcmp(_argv[i],"/nocolor")) opt.display.show_color = 0;
  else if(!strcmp(_argv[i],"/noext")) opt.display.show_ext = 0;
  else if(!strcmp(_argv[i],"/i")) opt.display.show_icon = 1;
  else if(!strcmp(_argv[i],"/v")) opt.display.vertical_display = 1;
  else if(!strcmp(_argv[i],"/?")||!strcmp(_argv[i],"/help")) help(_argv[i+1]);
  else if(!strcmp(_argv[i],"/ls")||!strcmp(_argv[i],"/l"))
   {
   col_folder = LIGHTBLUE;        //Folders
   col_executable = LIGHTGREEN;   //Executable Files(*.exe,*.com,*.bat)
   col_text = LIGHTGRAY;          //Text Files(*.txt,*.diz)
   col_html = LIGHTGRAY;          //HTML Files(*.htm)
   col_pics = MAGENTA;            //Picture Files(*.jpg,*.gif,*.bmp,*.tga,*.png)
   col_music = LIGHTGRAY;         //Music Files(*.mp3,*.ra,*.mid,*.wav)
   col_scripts = LIGHTGREEN;      //Programming Files/Scripts(*.vbs,*.js,*.pl,*.cpp,*.c)
   col_video = LIGHTGRAY;         //Video Files(*.mov,*.asf,*.dat,*.avi,*.mpg,*.mpe)
   col_compressed = RED;          //Compressed Files(*.zip,*.z,*.cab)
   col_unknown = LIGHTGRAY;       //Unknown Files
   }
  //Costom coloring for folders
  else if(!strcmp(_argv[i],"/dir"))//Folders
   { if(isColor(_argv[i+1]) >= 0) col_folder = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/exe"))
   { if(isColor(_argv[i+1]) >= 0) col_executable = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/txt"))
   { if(isColor(_argv[i+1]) >= 0) col_text = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/html"))
   { if(isColor(_argv[i+1]) >= 0) col_html = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/pics"))
   { if(isColor(_argv[i+1]) >= 0) col_pics = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/music"))
   { if(isColor(_argv[i+1]) >= 0) col_music = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/source"))
   { if(isColor(_argv[i+1]) >= 0) col_scripts = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/video"))
   { if(isColor(_argv[i+1]) >= 0) col_video = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/zip"))
   { if(isColor(_argv[i+1]) >= 0) col_compressed = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/others"))
   { if(isColor(_argv[i+1]) >= 0) col_unknown = isColor(_argv[i+1]); }
  //Custom Background Colouring
  else if(!strcmp(_argv[i],"/dir_back"))//Folders
   { if(isColor(_argv[i+1]) >= 0) col_folder_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/exe_back"))
   { if(isColor(_argv[i+1]) >= 0) col_executable_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/txt_back"))
   { if(isColor(_argv[i+1]) >= 0) col_text_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/html_back"))
   { if(isColor(_argv[i+1]) >= 0) col_html_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/pics_back"))
   { if(isColor(_argv[i+1]) >= 0) col_pics_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/music_back"))
   { if(isColor(_argv[i+1]) >= 0) col_music_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/source_back"))
   { if(isColor(_argv[i+1]) >= 0) col_scripts_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/video_back"))
   { if(isColor(_argv[i+1]) >= 0) col_video_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/zip_back"))
   { if(isColor(_argv[i+1]) >= 0) col_compressed_back = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/others_back"))
   { if(isColor(_argv[i+1]) >= 0) col_unknown_back = isColor(_argv[i+1]); }
  //Custom Attribute Colouring - Background
  else if(!strcmp(_argv[i],"/readonly")||!strcmp(_argv[i],"/ro"))
   { if(isColor(_argv[i+1]) >= 0) bg_readonly = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/hidden")||!strcmp(_argv[i],"/hide"))
   { if(isColor(_argv[i+1]) >= 0) bg_hidden = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/system")||!strcmp(_argv[i],"/sys"))
   { if(isColor(_argv[i+1]) >= 0) bg_system = isColor(_argv[i+1]); }
  //Custom Attribute Colouring - Font Color
  else if(!strcmp(_argv[i],"/readonly_text"))
   { if(isColor(_argv[i+1]) >= 0) col_readonly = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/hidden_text"))
   { if(isColor(_argv[i+1]) >= 0) col_hidden = isColor(_argv[i+1]); }
  else if(!strcmp(_argv[i],"/system_text"))
   { if(isColor(_argv[i+1]) >= 0) col_system = isColor(_argv[i+1]); }
  }
 if(!strcmp(_argv[2],"-debug")) debug=1;
 ////////////////////////////////////////////////////////////////////////

 //Get Curent Workind Directory(cwd)
 getcwd(dir,MAXPATH);
 gotoxy(1,y-1);
 textcolor(LIGHTGRAY);
 cputs("Directory listing of ");cputs(dir);

 //For getting Files and Folders in CWD
 struct ffblk ffblk;
 int done;

 //Attribute Information
 /*
 None     0
 Readonly 1
 Hidden   2
 System   4
 Folder   16
 Archive  32

 Add them to get the total
 Example: If the value of 'ffblk.ff_attrib' is 6, then it is 4 + 2.
	So the file is System and hidden.
 */

 int atb,show_file,attrib,show_folder;
 //For Folders
 done = findfirst(wild_card,&ffblk,FA_DIREC+FA_HIDDEN+FA_SYSTEM+FA_RDONLY);
 while (!done&&opt.display.show_folders)
  {
  show_folder=1;
  attrib=0;
  atb=int(ffblk.ff_attrib);

  //System Folder
  if((atb>=20&&atb<=23)||(atb>=52&&atb<=55))
   {
   if(!opt.display.show_system_files) show_folder=0;
   attrib=1;
   }
  //Hidden Folder
  else if(atb==18||atb==19||atb==50||atb==51)
   {
   if(!opt.display.show_hidden_files) show_folder=0;
   attrib=2;
   }
  //Read Only Folder
  else if(atb==17||atb==49)
   {
   attrib=3;
   }
  //Non Folder(File)
  else if(atb!=16&&atb!=48)
   {
   show_folder=0;
   }

  //Display the folder
  if(show_folder) folder(ffblk.ff_name,attrib);
  done = findnext(&ffblk);
  }

 //For Files
 done = findfirst(wild_card,&ffblk,FA_HIDDEN+FA_SYSTEM+FA_RDONLY);
 while (!done&&opt.display.show_files)
  {
  show_file=1;
  attrib=0;
  atb=int(ffblk.ff_attrib);

  //System File
  if(atb==4||atb==5||atb==6||atb==36||atb==37||atb==38||atb==39)
   {
   if(!opt.display.show_system_files) show_file=0;
   attrib=1;
   }
  //Hidden File
  else if(atb==2||atb==3||atb==34||atb==35)
   {
   if(!opt.display.show_hidden_files) show_file=0;
   attrib=2;

   }
  //Read Only
  else if(atb==1||atb==33)
   {
   attrib=3;
   }

  //Display the file
  if(show_file) files(ffblk.ff_name,attrib);
  done = findnext(&ffblk);
  }

 cout<<"\n";
 if(debug)
  {
  cout<<"Args : ";
  for (i=1;i<_argc;i++)
   {
   cout<<_argv[i]<<" ";
   }
  }

 if(opt.display.vertical_display) gotoxy(1,24);
 if(!strcmpi(_argv[1],"-wait")||!strcmpi(_argv[2],"-wait")||debug) getch(); //DEBUG
 }

/****************************************************************************
History
=======
Version 1.00.C
--------------
First Public Release
Started On 24-10-03
Ended on 4-11-03

Version 1.00.D
--------------
Bug fix for files without extension. It created a 'Abnomal program termination' error message.

Version 1.00.E
--------------
Added support for some more filetypes like Compressed files, movies, etc.
Added support for the /l command line which emulates the colours in the 'ls' command in linux

Version 1.01.A
--------------
Changed some colours for the display(Executable and HTML Files were changed)
Added the option for vertical display

Version 1.01.B
--------------
Minor Bug fixes regading the display of folders.
This Version got listed in CFS(Completly Free Software). Got mail from users

--------------
Version 2.00.A
--------------
Added support for diffrent attributes. It can be shown in a varity of background colours.
The colours of all file types can be configured using the command line.
Each filetype can have a background colour.
Gave option to exit program at every screen fill.
Giving a wild card as argument will not show the folders.
/? help will pause at every screen fill(By option).
Lots of changes in the code.

****************************************************************************/