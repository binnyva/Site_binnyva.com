var field_count = 1;
var code = '';

//Create the fieldset for a new database field.
function newField() {
	field_count++;
	var field = document.createElement("div");
	//InnerHTML is propabily the safest approch - cloneNode is possible - but we need to change the ids and everything.
	field.innerHTML = code.replace(/%COUNT%/g,field_count);
	$('extra_fields').appendChild(field);
	
	registerEventHandles(field_count);
	makeHelpText(field_count);
}

function fieldOptions(ele) {
	var type = ele.value;
	var field = ele.parentNode;

	var parts = ele.id.split('_');
	var fc = parts[parts.length-1];

	var field = $('field_'+fc);
	var options = document.getElementsByClassName('type_options', field);
	for(var i=0; i<options.length; i++) {
		Element.hide(options[i]);
	};

	if(type == 'file') {
		document.getElementsByClassName('file_options',field)[0].style.display = 'block';
	} else if(type == 'date') {
		document.getElementsByClassName('date_options',field)[0].style.display = 'block';
	} else if(type == 'list') {
		document.getElementsByClassName('list_options',field)[0].style.display = 'block';
	}
}

function registerEventHandles() {
	for (var i = 0; fc=arguments[i], i<arguments.length; i++) {
		if(!$('adm_field_type_'+fc)) continue;

		$('adm_field_type_'+fc).onchange = function(e) {
			if(!e) e = window.event;
			var ele = this || e.src;
			fieldOptions(ele);
		}
	}
}
function makeHelpText(field_count) {
	var helps = []
	if(field_count) {
		helps = document.getElementsByClassName("help",$('field_'+field_count));
	} else {
		helps = document.getElementsByClassName("help");
	}
	
	for(var i=0; i<helps.length; i++) {
		var help_text = helps[i].innerHTML;
		helps[i].innerHTML = "<a href='#' onmouseover='tip(this,\""+escape(help_text)+"\")' onmouseout='clearTip()'> ? </a>"
	}
}
function tip(ele,help_text) {
	if(!$('tip')) return;
	$('tip-holder').style.display = "block";
	var xy = Position.cumulativeOffset(ele)
	$('tip-holder').style.left = xy[0] + 10 + "px";
	$('tip-holder').style.top = xy[1] + "px";
	
	$('tip').innerHTML = unescape(help_text);
}
function clearTip() {
	if(!$('tip')) return;
	$('tip-holder').style.display = "none";
	$('tip').innerHTML = ''
}
function init() {
	//Get the HTML required for making more fields.
	code = '<fieldset class="field" id="field_%COUNT%">' + $('field_1').innerHTML + '</fieldset><br />';
	code = code.replace(/_1/g,"_%COUNT%");
	code = code.replace(/Field 1/g,"Field %COUNT%");

	$('adm_title').onchange = function() {
		var title = $F('adm_title');
		if( !$F('adm_table') ) $('adm_table').value = $F('adm_title').toLowerCase();
		if( !$F('adm_file')  ) $('adm_file').value  = $F('adm_table') + ".php";
		if( !$F('adm_single')) $('adm_single').value= $F('adm_title').replace(/e?s$/i,'');
	}
	registerEventHandles(1);
	makeHelpText(0);
}
window.onload=init;