     Binny's Software - Bible Aid Vs.2.1
This software is for those who try to read the 
Bible completly withing a limited period of time.
You can record your progress in a very helpful 
interface and see how much more chapters you have
to read, how many days, how many chapters you have
to read per day to reach the target, etc.

This is a highly customizable software. You can 
create multiple user - upto 10(If you want more
users, please let me know and I will make the 
nessary arrengmets), with Login at the start
with password support. You can change all colours
in the programs according to your choice.

Author : Binny V Abraham
Company: Binny's Softwares
Website: http://binnyva.tripod.com
E-Mail : binnyva@hotmail.com
Postal Address:
Binny V Abraham
Kalloor Villa
Ambalam Unichar Road
Kunamthia
Changam Puzha PO
Cochin 24
Kerala
India
